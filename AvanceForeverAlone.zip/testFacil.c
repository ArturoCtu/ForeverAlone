program alone;
var int a, b, c; 
	float d, e, f;
	char g;

function float fact(int i, j, k)
var int ia;
	float dj;
{
i = 10;
return i;
}
function void suma(int aj, int bj)
var int res;
{
	res = aj + bj * c / 10;
}
main(int baboso, float alv)
var int j, k, l, iterator;
	float x[10], y[8];
{
	read(a);
	if(j > k || k < l) then{
		print("lol", 'c');
	} else {
		print("burro lol");
		j = l + k;
	}
		
	while(iterator < 10){
		iterator = iterator + 1;
	}
	print("thanks");
}
end